# Certificación Huawei — Corte 3

## 1. Portada

**Estudiante:** Juan Jose Guzman Bohorquez  
**Código estudiantil:** 9024125776  
**Programa:** Ingeniería de Sistemas  
**Asignatura:** Electiva Inteligencia de Negocios  
**Docente:** Jesús Ariel González Bonilla  
**Curso:** HCIA-Big Data V3.5 Course  
**Plataforma:** Huawei Talent  
**Duración del curso:** 32 horas  
**Link Del Fork:** https://github.com/juanjoGuzmanBohorquez/inteligencia-negocios-2026-b-g1.git 
**Fecha de entrega:** 4/11/2026

## 2. Constancia de finalización

Huawei ICT Academy emitió la constancia del curso a nombre de Juan Jose Guzman Bohorquez. La fecha de emisión impresa es **5 de noviembre de 2026**.

![Constancia de finalización de Huawei ICT Academy](HCIA-Big%20Data%20V3.5%20Course.png)

## 3. Evidencia de avance por capítulo

### 1. Big Data Development Trends

![Avance del capítulo 1](1.%20Big%20data%20development%20trends.png)

### 2. HDFS and ZooKeeper

![Avance del capítulo 2](2.%20HDF5%20-%20hadoop%20distributed.png)

### 3. HBase and Hive

La lista lateral de la captura del capítulo 4 muestra el capítulo 3 marcado como completado. [Agregar captura individual del capítulo 3.]

### 4. ClickHouse

![Avance del capítulo 4](4.%20clickhouse-%20online%20analytiical.png)

### Final De Todos los Cursos

![Avance general del curso al 98 %](Final%20De%20Todos%20Los%20Cursos%20De%20Big%20Data.png)



## 4. Resultado del examen

La captura del **HCIA-Big Data V3.5 Mock Exam** muestra un resultado aprobado de **850 puntos**, con **51 de 60** respuestas correctas.

![Resultado del Mock Exam de Huawei](Nota%20final%20del%20examen%20final%20.png)

## 5. Conexión con Inteligencia de Negocios

**Proyecto de aula:** PixelZone Gaming

Si PixelZone Gaming creciera diez veces, tendría que manejar muchos más registros de ventas e inventario. Los conceptos del curso me ayudaron a entender cómo podría organizar esos datos y usarlos para decidir qué productos comprar y en qué canales hacer promociones.

### Hive

Con Hive aprendí cómo se puede consultar un historial de datos almacenado de forma distribuida. Lo relaciono con el almacén de datos que vimos en Inteligencia de Negocios. En PixelZone Gaming lo usaría para guardar y consultar las ventas de varios años por producto, fecha y canal. Por ejemplo, podría revisar qué accesorios se venden más en temporadas como diciembre y usar ese historial para planear las compras antes de la siguiente temporada.

### ClickHouse

Con ClickHouse entendí cómo una base de datos orientada a OLAP ayuda a resumir grandes cantidades de registros para responder preguntas del negocio. En PixelZone Gaming lo usaría para comparar las unidades vendidas por categoría, canal y mes. Por ejemplo, si los controles se vendieran mejor en línea y los audífonos en la tienda física, usaría esa comparación para decidir dónde concentrar la promoción de cada producto.

### Huawei DataArts Studio

Este tema lo relaciono con ETL y calidad de datos. Si PixelZone Gaming creciera, usaría DataArts Studio para integrar los registros de ventas y de inventario antes de alimentar el tablero. Revisaría que cada código de producto exista en el catálogo y comprobaría que una misma línea de venta no se haya cargado dos veces. Así, el tablero mostraría cantidades más confiables para decidir qué productos reponer.

## 6. Skills summary

I can explain how Hive supports queries on large historical datasets.  
I can describe how OLAP helps compare sales across products, channels, and months.  
I can explain why ClickHouse is useful for analytical queries.  
I can identify the main steps of an ETL process.  
I can describe how to check for duplicate records and invalid product codes.  
I can explain how clean sales and inventory data support purchasing and promotion decisions.