# Ventas mensuales — Semana 7

Actividad de Inteligencia de Negocios: combinación de archivos CSV mediante Power Query.

## Objetivo

Combinar las ventas de tres meses en una sola tabla y permitir que se incorporen nuevos archivos al actualizar los datos.

## Herramientas

- Power BI web.
- Power Query.
- OneDrive institucional y el conector Carpeta de SharePoint.

## Archivos utilizados

Se crearon tres archivos con datos ficticios para fines académicos:

- ventas-julio.csv
- ventas-agosto.csv
- ventas-septiembre.csv

Cada archivo contiene tres ventas y utiliza las mismas columnas:

| Columna | Descripción |
|---|---|
| VentaID | Identificador de la venta |
| Fecha | Fecha de la venta |
| Producto | Nombre del producto |
| Categoria | Categoría del producto |
| Cantidad | Unidades vendidas |
| Total | Valor total de la venta |

## Proceso en Power Query

1. Se cargaron los tres CSV en la carpeta ventas-mensuales del OneDrive institucional.
2. En Power BI web se seleccionó Obtener datos y el conector Carpeta de SharePoint.
3. Se estableció la conexión mediante la cuenta institucional.
4. Se filtró la columna Folder Path para conservar las rutas que contienen /ventas-mensuales/.
5. Se seleccionó Combinar archivos en la columna Content.
6. Se utilizó la codificación UTF-8 y la coma como delimitador.
7. Power Query aplicó la transformación del archivo de ejemplo a los tres CSV y combinó sus registros.
8. La consulta se nombró VentasMensuales y se cargó al modelo.
9. Se creó una tabla en el informe para visualizar los datos combinados.

Los pasos de la consulta se muestran en la captura del panel Pasos aplicados.

## Resultado

La tabla combinada contiene las nueve ventas de julio, agosto y septiembre.

| Indicador | Resultado |
|---|---:|
| Archivos combinados | 3 |
| Ventas | 9 |
| Unidades vendidas | 30 |
| Valor total de ventas | 1.210.000 |

En el visual de tabla, VentaID se configuró como No resumir para mostrar el identificador de cada venta.

## Incorporación de un nuevo mes

Para incorporar octubre, se debe crear ventas-octubre.csv con las mismas columnas, encabezados y delimitador que los archivos anteriores.

El archivo se carga en la misma carpeta ventas-mensuales del OneDrive institucional. Después se actualizan los datos del modelo semántico en Power BI.

Durante la actualización, Power Query vuelve a consultar la carpeta y aplica las transformaciones existentes al nuevo archivo. Sus registros se incorporan a la tabla sin volver a crear la conexión ni repetir la combinación manualmente.

El filtro utiliza la ruta de la carpeta, por lo que no depende de los nombres de los tres archivos originales.

