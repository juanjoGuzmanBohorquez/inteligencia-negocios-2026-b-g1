# Mini-ETL y primeras medidas

Actividad de Inteligencia de Negocios realizada en Power BI web desde un Mac.

## Dataset

`dirty_sales.csv` es un dataset sintético creado para esta actividad. Tiene 12 registros originales, duplicados, espacios sobrantes y categorías con mayúsculas y minúsculas inconsistentes.

## Pasos aplicados

1. Definir SaleID, Quantity y Sales como enteros, Date como fecha y Product y Category como texto.
2. Eliminar duplicados usando SaleID: de 12 a 10 filas.
3. Recortar espacios al inicio y final de Product y Category.
4. Crear la columna MAYÚSCULAS a partir de Category para uniformar las categorías.

La consulta SalesData se cargó al modelo semántico.

## Medidas DAX

```dax
Total Sales = SUM(SalesData[Sales])
```

Suma las ventas.

```dax
Average Sale = AVERAGE(SalesData[Sales])
```

Calcula el promedio del importe de los registros de venta.

```dax
Sales per Unit = DIVIDE([Total Sales], SUM(SalesData[Quantity]), 0)
```

Calcula ventas por unidad y devuelve cero cuando el denominador es cero.

## Contexto de filtro

Usar una tabla con las tres medidas y una segmentación de datos con MAYÚSCULAS. Seleccionar TECHNOLOGY para comparar con el resultado sin filtro.

| Medida | Sin filtro | TECHNOLOGY | STATIONERY |
|---|---:|---:|---:|
| Total Sales | 998000 | 910000 | 88000 |
| Average Sale | 99800 | 182000 | 17600 |
| Sales per Unit | 26972.97 | 101111.11 | 3142.86 |

El filtro limita los registros utilizados por cada medida a la categoría seleccionada.

## Evidencias

### Pasos aplicados y tabla limpia

Se muestran los tipos, la eliminación de duplicados, el recorte y la columna MAYÚSCULAS. La tabla final tiene diez filas y siete columnas.

![Pasos aplicados y tabla limpia](evidence/pasos-aplicados.png)

### Medidas sin filtro

![Tres medidas sin filtro](evidence/sin-filtro.png)

### Filtro TECHNOLOGY

![Medidas con TECHNOLOGY seleccionado](evidence/filtro-technology.png)

### Filtro STATIONERY

![Medidas con STATIONERY seleccionado](evidence/filtro-stationery.png)

### Vista del informe en Power BI

![Informe con tabla y segmentación](evidence/informe-technology.png)

## Cómo reproducir

1. Importar dirty_sales.csv con Power Query en Power BI web.
2. Aplicar las cuatro transformaciones descritas y llamar SalesData a la consulta.
3. Cargar la consulta al modelo semántico y crear las medidas DAX.
4. Crear una tabla con las medidas y una segmentación con MAYÚSCULAS.
5. Comparar los resultados sin filtro y con TECHNOLOGY seleccionado.
6. Guardar el informe.

## ETL steps & measures

I used a synthetic sales CSV file containing duplicate records, extra spaces, and inconsistent category names.
I assigned the correct data types to the date, text, and numeric columns.
I removed duplicate records using SaleID, reducing the dataset from twelve rows to ten rows.
I trimmed leading and trailing spaces from the Product and Category columns.
I created an uppercase category column named MAYÚSCULAS to group equivalent category names consistently.
I loaded the cleaned SalesData table into the semantic model.
I created the Total Sales measure with SUM to calculate total sales.
I created the Average Sale measure with AVERAGE to calculate the average sales amount per record.
I created the Sales per Unit measure with DIVIDE to calculate sales per unit and handle a zero denominator.
The category slicer changes the active filter context and recalculates the measures for the selected category.
