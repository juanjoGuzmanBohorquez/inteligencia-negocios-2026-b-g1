# Semana 9 — Primeras medidas DAX en Power BI

## Objetivo

Crear cuatro medidas básicas en DAX y observar cómo cambia su resultado según el contexto de filtro.

## Herramientas y datos

La actividad se realizó en Power BI web desde un Mac, utilizando el modelo del Titanic limpiado en la semana 8.

- Informe: Limpieza Titanic.
- Tabla del modelo: `titanic 1`.
- Fuente pública: https://github.com/mwaskom/seaborn-data/blob/master/titanic.csv
- Grano de los datos: cada fila representa un pasajero.

## 1. Medidas creadas

### Total de tarifas — SUM

```dax
Total tarifas = SUM('titanic 1'[fare])
```

Suma las tarifas de los pasajeros incluidos en el contexto de filtro actual.

### Edad promedio — AVERAGE

```dax
Edad promedio = AVERAGE('titanic 1'[age])
```

Calcula el promedio de edad de los pasajeros incluidos en el contexto actual. Las edades vacías se excluyen del promedio; no se consideran como cero.

### Total de pasajeros — COUNTROWS

```dax
Total pasajeros = COUNTROWS('titanic 1')
```

Cuenta las filas de la tabla. Como cada fila corresponde a un pasajero, permite conocer cuántos pasajeros hay en el contexto actual.

### Tarifa promedio por pasajero — DIVIDE

```dax
Tarifa promedio por pasajero =
DIVIDE([Total tarifas], [Total pasajeros])
```

Divide el total de tarifas entre el número de pasajeros. Es una medida derivada porque utiliza otras dos medidas.

`DIVIDE` devuelve un valor en blanco si el denominador es cero o está vacío, ya que no se indicó un resultado alternativo.

## 2. Procedimiento

1. Abrí el modelo semántico en Power BI web y activé el modo de edición.
2. Seleccioné la tabla `titanic 1`.
3. Creé las cuatro medidas mediante la opción Nueva medida.
4. Abrí el informe Limpieza Titanic en modo de edición.
5. Agregué una tarjeta con la medida Total tarifas.
6. Agregué una tabla con la columna `class` y la misma medida Total tarifas.
7. Añadí las otras tres medidas a la tabla.
8. Guardé el informe y tomé las capturas de evidencia.

## 3. Tarjeta frente a tabla por dimensión

Utilicé `class` como dimensión para comparar las clases First, Second y Third.

| Visualización | Contexto | Resultado que representa |
| --- | --- | --- |
| Tarjeta con Total tarifas | Sin filtro de clase | Suma de tarifas de todos los pasajeros disponibles |
| Fila First | Solo primera clase | Suma de tarifas de los pasajeros de First |
| Fila Second | Solo segunda clase | Suma de tarifas de los pasajeros de Second |
| Fila Third | Solo tercera clase | Suma de tarifas de los pasajeros de Third |
| Fila Total | Todas las clases disponibles | Total general de tarifas |

La tarjeta y la tabla utilizan exactamente la misma medida. El resultado cambia porque cada fila de la tabla restringe el cálculo a una clase.

Esta comparación supone que no hay otros filtros o selecciones que restrinjan los pasajeros.

## 4. Explicación del contexto de filtro

Entiendo el contexto de filtro como las condiciones que determinan qué datos utiliza una medida para calcular su resultado.

En mi ejemplo, la tarjeta muestra el total de tarifas de todos los pasajeros disponibles. En cambio, la fila First de la tabla calcula el total únicamente para los pasajeros de primera clase.

No tuve que crear una fórmula diferente para cada clase. Power BI utiliza la misma medida y la calcula con los datos que corresponden a cada fila.

El contexto también puede cambiar cuando se aplican filtros o segmentadores al informe.

En la fila Total, los promedios se calculan nuevamente sobre todos los pasajeros disponibles. No se suman los promedios de las tres clases.

## 5. Medidas frente a columnas calculadas

Las cuatro fórmulas son adecuadas como medidas porque resumen varios registros y deben responder a los filtros del informe.

| Medida | Justificación |
| --- | --- |
| Total tarifas | Debe sumar las tarifas del grupo seleccionado |
| Edad promedio | Debe calcular el promedio del grupo seleccionado |
| Total pasajeros | Debe contar los pasajeros incluidos en los filtros |
| Tarifa promedio por pasajero | Debe recalcular la división para el grupo seleccionado |

Por eso, ninguna de estas cuatro medidas necesita convertirse en columna calculada.

Una clasificación individual como “Menor de edad” o “Adulto” sí sería adecuada como columna, porque asigna una categoría a cada pasajero y puede utilizarse para agrupar o filtrar. También podría crearse previamente en Power Query, definiendo cómo tratar las edades faltantes.

## 6. Archivos de entrega

- `README.md`: fórmulas, procedimiento y explicaciones.
- `evidencias/01-tarjeta-y-tabla.png`: comparación de la misma medida en tarjeta y tabla.
- `evidencias/02-cuatro-medidas.png`: resultados de las cuatro medidas por clase.